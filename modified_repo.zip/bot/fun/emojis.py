import random


def enmoji():
    emoji = (
        "🤓",
        "😎",
        "🤠",
        "🌚",
        "🛰️",
        "❤️",
        "📡",
        "🥺",
        "🌝",
        "☺️",
        "😊",
        "😑",
        "📌",
        "🥸",
        "😵‍💫",
        "🪩",
        "✅",
    )
    y = random.choice(emoji)
    return y


def enmoji2():
    emoji = (
        "❌",
        "❎",
        "✖️",
        "☠️",
        "💀",
        "🧟",
        "💔",
        "⚰️",
        "⛔",
        "🫠",
    )
    y = random.choice(emoji)
    return y


def enhearts():
    emoji = (
        "♥️",
        "❤️",
        "💛",
        "💚",
        "🩷",
        "💜",
        "🩵",
        "💙",
        "🤎",
        "🧡",
        "🩶",
        "🖤",
    )
    y = random.choice(emoji)
    return y
