import random


def enquip():
    quip = (
        "awake and ready to serve you, young master!",
        "Up!",
        "a coconut.",
        "the fastest bot alive.",
        "ready to encode from dusk till dawn.",
        "ready and awaiting orders, Sir! Yes Sir!",
        "feeling lucky+",
        "(technically) a noble bot.",
        "the... Core!",
        "stunned, yet not surprised, by your kind gesture.",
        "the highest bot.",
        "the Archduke’s daughter, Maiodore in disguise.",
        "Ready!",
    )
    y = random.choice(quip)
    return y


def enquip2():
    quip = (
        "dying…\nSo the end is nigh uh \n thank you for allowing me to serve you bo-chan!\nfarewell.",
        "Down!",
        "ready to retire.",
        "disintegrating?\nNo it's thawne he erased me from the timeline by destroying the speed lib.",
        "done, Sir! Yes Sir!",
        "dismayed\nHow could you do this to me",
        "still (technically) a noble bot.\nand would remain one even in death.",
        "the grim reaper.",
        ".....................................................",
        "dismayed, yet not seeking vengeance\n'though alas this is where I meet my end.'",
        "…\n\n Screw this!\n It's those servers they're ev---. [dies]",
        "done.",
        "[Terminated].",
    )
    y = random.choice(quip)
    return y


def enquip3():
    quip = (
        "It won't kill you to make me an admin, you know.",
        "Make me an admin, now!",
        "Would you look at that, I'm not an admin uh, who knew?",
        "I need to be an admin to carry out some functions.",
    )
    y = random.choice(quip)
    return y


def enquip4():
    quip = (
        "It's Really busy in here, uh?",
        "Let's gooo…",
        "Anyone knows a good hosting platform?",
        "Seems interesting.",
        "The Sky WAS The Limit",
        "Kids this days…",
        "Arrgh, my back!",
        "Hello there, whippersnappers!",
        "Shared Hosting?, what sort of abomination is that?",
        "Someone buy me a server.",
        "Wha- Where am I? Hello?",
        "Donating is also an excellent decision.",
        "Picking up a light novel is an excellent decision.",
        "You could also read a book sometimes.",
        "Babe, wake up. New release just dropped.",
        "And so it begins…",
        "It is what it is.",
        "Oh hell naw!",
        "What's Poppin?",
        "This is Kangaroo Court",
        "Behold, The Warrior of servers",
        "H-Haters Gonna H-Hate",
        "Well? We're Waiting!",
        "If Google Can Get Away With It, Why Can't I?",
        "Oooo, Ghoooosts",
        "Aha ha... S-Suspicious person, I am not...",
        "HOORAAAY",
        "Don’t give up! Try a little harder! You can do it!!!",
        "English or Spa- Just kidding! I swear! So put the knife down!, Please?!",
        "Crowdstrike? what's that?",
    )
    y = random.choice(quip)
    return y
